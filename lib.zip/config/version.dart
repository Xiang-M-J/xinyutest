class Version {
  static String version = 'v2.2.2';
}
