class SubjectsList{
  /// 被试者列表
  static var subjects;
  /// 选中的被试者的索引
  static int index = 0;
}