class UserRole{
  /// 主试者角色
  static String role = '数据收集';
}