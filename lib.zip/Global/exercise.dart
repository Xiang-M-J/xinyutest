class ExerciseInfo{
  /// 已完成的联系表的数量
  static int TableNumber_Finished = 0;
  /// 用于练习模式两张表交替出现
  static bool isFirstExercise = true;
}